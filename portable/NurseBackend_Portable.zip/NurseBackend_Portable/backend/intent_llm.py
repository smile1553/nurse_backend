import os, json, re
from collections import OrderedDict
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
import openai
from intent_rules import apply_intent_rules
from runtime_paths import BASE_DIR
from env_config import (
    OPENAI_API_KEY_TEMPLATE_VALUE,
    initialize_environment,
    read_api_key,
)

initialize_environment()

LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
LLM_TIMEOUT_SEC = float(os.getenv("LLM_TIMEOUT_SEC", "2.5"))
LLM_CACHE_SIZE = int(os.getenv("LLM_CACHE_SIZE", "256"))
_LLM_CACHE = OrderedDict()
TOXIC_AS_THREAT_MIN = float(os.getenv("TOXIC_AS_THREAT_MIN", "0.6"))
API_KEY_TEMPLATE_VALUE = OPENAI_API_KEY_TEMPLATE_VALUE


FALLBACK = {
    "intent": "neutral",
    "action_tag": "neutral",
    "sentiment": "neutral",
    "toxicity": 0.0,
    "coercion": 0.0,
    "confidence": 0.0,
    "keywords": []
}

ALLOWED_INTENTS = {"reassure", "encourage", "neutral", "command", "force", "threat"}
ALLOWED_ACTION_TAGS = {
    "neutral",
    "reassure",
    "encourage",
    "distract",
    "command",
    "force",
    "threat",
    "ask_consent",
    "praise",
    "ask_preference",
    "calm_guidance",
    "coach_comfort_words",
    "delay_temp_exam",
    "engagement_strategy",
    "explain_resp_first",
    "introduce_bp_exam",
    "invite_bp_cooperation",
    "practice_before_exam",
    "praise_child",
    "reassure_child",
    "reduce_fear",
    "role_play_demo",
    "role_play_temp",
    "temp_reassurance",
    "transition_to_temp",
    "closing_praise",
    "scenario_wrap_up",
}
INTENT_ALIASES = {
    "distract": "reassure",
    "ask_consent": "reassure",
    "explain": "neutral",
    "praise": "encourage",
    "threaten": "threat",
    "comfort": "reassure",
    "安撫": "reassure",
    "轉移注意": "distract",
    "同意確認": "ask_consent",
    "ask consent": "ask_consent",
    "instruction": "command",
    "命令": "command",
    "解釋": "explain",
    "稱讚": "praise",
    "威脅": "threaten",
}
ACTION_TAG_ALIASES = {
    "greet_and_introduce": "introduce_bp_exam",
    "greeting": "introduce_bp_exam",
    "intro": "introduce_bp_exam",
    "introduce_exam": "introduce_bp_exam",
    "介紹檢查": "introduce_bp_exam",
    "介紹血壓": "introduce_bp_exam",
    "說明先觀察呼吸": "explain_resp_first",
    "先觀察呼吸": "explain_resp_first",
    "呼吸優先": "explain_resp_first",
    "安撫引導": "calm_guidance",
    "同意確認": "ask_consent",
    "詢問喜好": "ask_preference",
    "分散注意": "engagement_strategy",
    "貼紙鼓勵": "reduce_fear",
    "角色扮演示範": "role_play_demo",
    "角色扮演量體溫": "role_play_temp",
    "耳溫安撫": "temp_reassurance",
    "延後耳溫": "delay_temp_exam",
    "轉換到耳溫": "transition_to_temp",
    "鼓勵量血壓": "invite_bp_cooperation",
    "說明量血壓": "introduce_bp_exam",
    "收尾稱讚": "closing_praise",
}
SENTIMENT_ALIASES = {
    "pos": "positive",
    "neg": "negative",
    "中性": "neutral",
    "正向": "positive",
    "負向": "negative",
}
ALLOWED_SENTIMENTS = {"positive", "neutral", "negative"}
KEYWORD_ALIASES = {
    "雅瑤": "芽芽",
    "丫丫": "芽芽",
    "鴨鴨": "芽芽",
    "馬小芽": "芽芽",
    "媽咪": "媽媽",
}
def _read_key_file(path: str) -> Optional[str]:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        key = data.get("apiKey") or data.get("OPENAI_API_KEY")
        if not isinstance(key, str):
            return None
        key = key.strip()
        if not key or key == API_KEY_TEMPLATE_VALUE:
            return None
        return key
    except Exception as e:
        print(f"[intent_llm] failed to read {os.path.basename(path)}: {e}")
        return None


def ensure_api_key_template(path: str) -> bool:
    """Create a safe API-key template once; never overwrite an existing file."""
    if os.path.exists(path):
        return False
    try:
        with open(path, "x", encoding="utf-8") as f:
            json.dump({"apiKey": API_KEY_TEMPLATE_VALUE}, f, ensure_ascii=False, indent=2)
            f.write("\n")
        print(f"[intent_llm] created API key template: {path}")
        return True
    except FileExistsError:
        return False
    except OSError as e:
        print(f"[intent_llm] failed to create API key template: {e}")
        return False


def load_api_key() -> Optional[str]:
    base = str(BASE_DIR)
    legacy_key_path = os.path.join(base, "openai_api.json")
    ensure_api_key_template(legacy_key_path)

    # Prefer environment/.env for server deployments; JSON files are legacy fallbacks.
    env_key = read_api_key("OPENAI_API_KEY", API_KEY_TEMPLATE_VALUE)
    if env_key:
        return env_key

    local_key = _read_key_file(os.path.join(base, "openai_api.local.json"))
    if local_key:
        return local_key

    # 最後相容舊檔名
    return _read_key_file(legacy_key_path)


api_key = load_api_key()
if api_key:
    # One explicit client keeps its HTTP connection pool across utterances.
    # Output length remains unrestricted to avoid truncating the required JSON.
    openai_client = openai.OpenAI(
        api_key=api_key,
        timeout=LLM_TIMEOUT_SEC,
    )
else:
    openai_client = None
    print("[intent_llm] API key missing, fallback mode enabled.")


class IntentSchema(BaseModel):
    intent: str = Field(description="reassure|encourage|neutral|command|force|threat")
    action_tag: str = Field(description="specific scenario semantic tag in snake_case; use neutral if unclear")
    sentiment: str = Field(description="positive|neutral|negative")
    toxicity: float
    coercion: float
    confidence: float
    keywords: List[str]


SYSTEM_PROMPT = (
    "你是兒科護理情境的語言分析器。請使用 previous_utterance 理解 current_utterance，"
    "但只根據 current_utterance 選擇一個 intent："
    "reassure、encourage、neutral、command、force、threat。"
    "force 表示強迫行為，threat 表示威脅後果。"
    "command 只用在沒有商量餘地的命令口氣（例如「躺下」「不要動」「快一點」「給我坐好」）。"
    "有禮貌、讓孩子或家屬可以選擇的請求與邀請，例如句尾是「好不好」「好嗎」「可以…嗎」「要不要」"
    "（「我們先幫熊熊量耳溫好不好」「芽芽你可以先躺下來嗎」），屬於徵求同意：intent 用 reassure，"
    "action_tag 用 ask_consent，不要判成 command 或 force。"
    "用獎勵邀請合作（例如「如果你讓我聽心跳，我就給你這張貼紙」）屬於 encourage，不是 force。"
    "道歉或收回剛才的兇話（例如「對不起芽芽我們剛剛太兇了」「不好意思剛剛太大聲了」）是安撫：intent 用 reassure，"
    "toxicity 要低；句子裡的「兇」是在描述自己剛才的行為，不是在威脅。"
    "辱罵、貶低、嘲笑、責罵或對孩子、家屬發脾氣的話（例如「你是白癡嗎」「吵死了」「煩不煩」）"
    "即使沒有提到後果，也一律歸為 threat，並給高 toxicity。"
    "只判斷 intent，不計算 tension、patience或emotion。"
    "action_tag 要選最貼近教案步驟的細分類。"
    "action_tag 優先從以下集合選擇：introduce_bp_exam、explain_resp_first、calm_guidance、ask_preference、engagement_strategy、"
    "role_play_demo、reduce_fear、praise_child、transition_to_temp、reassure_child、delay_temp_exam、role_play_temp、"
    "practice_before_exam、coach_comfort_words、temp_reassurance、invite_bp_cooperation、closing_praise、scenario_wrap_up、"
    "ask_consent、reassure、encourage、command、force、threat、neutral。"
    "如果輸入有 current_step_id、player_prompt、expected_intents，請把它們當成當前教案上下文來判斷 action_tag。"
    "如果句子太模糊或不屬於任何具體劇情行動，就用 neutral。"
    "只輸出 JSON：intent（reassure|encourage|neutral|command|force|threat）、action_tag、"
    "sentiment（positive|neutral|negative）、toxicity(0~1)、coercion(0~1)、"
    "confidence(0~1)、keywords（字串陣列）。只回 JSON，勿包含其他文字。"
)



def _cache_key(prev: str, current: str, context: Optional[Dict[str, Any]] = None) -> str:
    ctx = ""
    if context:
        try:
            ctx = json.dumps(context, ensure_ascii=False, sort_keys=True)
        except Exception:
            ctx = str(context)
    return f"{(prev or '').strip()}||{(current or '').strip()}||{ctx}"


def _cache_get(key: str):
    if key in _LLM_CACHE:
        val = _LLM_CACHE.pop(key)
        _LLM_CACHE[key] = val
        return val
    return None


def _cache_set(key: str, value: dict) -> None:
    _LLM_CACHE[key] = value
    while len(_LLM_CACHE) > max(1, LLM_CACHE_SIZE):
        _LLM_CACHE.popitem(last=False)


def _extract_json_object(text: str) -> dict:
    s = (text or "").strip()
    if not s:
        raise ValueError("empty LLM response")
    if s.startswith("```"):
        s = s.strip("`")
        s = s.replace("json\n", "", 1).strip()
    try:
        return json.loads(s)
    except Exception:
        m = re.search(r"\{[\s\S]*\}", s)
        if not m:
            raise
        return json.loads(m.group(0))


def _to_float(x, default=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _normalize_intent(x: str) -> str:
    key = (x or "").strip().lower()
    mapped = INTENT_ALIASES.get(key, key)
    mapped = {
        "distract": "reassure",
        "ask_consent": "reassure",
        "explain": "neutral",
        "praise": "encourage",
        "threaten": "threat",
    }.get(mapped, mapped)
    return mapped if mapped in ALLOWED_INTENTS else "neutral"


def _normalize_sentiment(x: str) -> str:
    key = (x or "").strip().lower()
    mapped = SENTIMENT_ALIASES.get(key, key)
    return mapped if mapped in ALLOWED_SENTIMENTS else "neutral"


def _normalize_action_tag(x: str) -> str:
    raw = (x or "").strip().lower()
    if not raw:
        return "neutral"
    raw = raw.replace("-", "_").replace(" ", "_")
    raw = ACTION_TAG_ALIASES.get(raw, raw)
    return raw if raw in ALLOWED_ACTION_TAGS else "neutral"


def _normalize_keywords(items) -> List[str]:
    if not isinstance(items, list):
        return []
    out: List[str] = []
    seen = set()
    for raw in items:
        if not isinstance(raw, str):
            continue
        k = raw.strip()
        if not k:
            continue
        k = KEYWORD_ALIASES.get(k, k)
        if len(k) > 20:
            continue
        if k in seen:
            continue
        seen.add(k)
        out.append(k)
    return out[:8]


def normalize_llm_output(data: dict) -> dict:
    base = dict(FALLBACK)
    if not isinstance(data, dict):
        return base

    base["intent"] = _normalize_intent(data.get("intent", ""))
    base["action_tag"] = _normalize_action_tag(data.get("action_tag", ""))
    base["sentiment"] = _normalize_sentiment(data.get("sentiment", ""))
    base["toxicity"] = max(0.0, min(1.0, _to_float(data.get("toxicity", 0.0))))
    base["coercion"] = max(0.0, min(1.0, _to_float(data.get("coercion", 0.0))))
    base["confidence"] = max(0.0, min(1.0, _to_float(data.get("confidence", 0.0))))
    base["keywords"] = _normalize_keywords(data.get("keywords", []))

    # Safety net: abusive speech that the model still labelled as harmless must not leave
    # the child's tension untouched. Treated like a threat so Unity needs no new intent.
    if base["toxicity"] >= TOXIC_AS_THREAT_MIN and base["intent"] in ("neutral", "reassure", "encourage"):
        base["intent"] = "threat"

    return base


def analyze_intent(recent_utterances: list[str], current: str, context: Optional[Dict[str, Any]] = None) -> dict:
    if openai_client is None:
        return FALLBACK.copy()

    prev = ""
    if recent_utterances:
        prev = (recent_utterances[-1] or "").strip()

    key = _cache_key(prev, current, context)
    cached = _cache_get(key)
    if cached is not None:
        return dict(cached)

    user_payload = {
        "previous_utterance": prev,
        "current_utterance": current
    }
    if context:
        for k in ("current_step_id", "player_prompt", "expected_intents"):
            v = context.get(k)
            if v:
                user_payload[k] = v
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)}
    ]
    try:
        resp = openai_client.chat.completions.create(
            model=LLM_MODEL,
            messages=messages,
            temperature=0,
        )
        txt = resp.choices[0].message.content
        raw = _extract_json_object(txt)
        data = normalize_llm_output(raw)
        IntentSchema(**data)  # 驗證格式
        # Fixed corrections for polite requests / apologies (see intent_rules.py).
        data = apply_intent_rules(data, current)
        _cache_set(key, data)
        return dict(data)
    except Exception as e:
        print("[LLM fallback]", e)
        return FALLBACK.copy()
