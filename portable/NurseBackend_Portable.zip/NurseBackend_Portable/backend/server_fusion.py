# server_fusion.py
import asyncio, json, re, time, io, os, tempfile, subprocess
from datetime import datetime
from pathlib import Path
from uuid import UUID
import numpy as np
import soundfile as sf
import httpx
from typing import Dict, Any, List, Tuple, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.responses import JSONResponse, Response, FileResponse, RedirectResponse
from discovery import DiscoveryService
import uvicorn
from collections import OrderedDict, deque
from deepgram_streaming import DeepgramStreamingError, DeepgramStreamingSession, DeepgramTranscriptResult
from env_config import (
    DEEPGRAM_API_KEY_TEMPLATE_VALUE,
    read_api_key,
)

from fusion_loop import (
    fuse_once,
    sanitize_transcript,
    clamp,
)
from semantic_analysis import (
    DEFAULT_SEMANTIC_ANALYSIS,
    analyze_semantics,
    semantic_tension_score,
    tension_to_kid_emotion_state,
    tension_to_patience_score,
    update_tension,
)
from tone_analysis import DEFAULT_TONE_ANALYSIS
from test_sensevoice import warmup_model
from excel_result_service import (
    ExcelResultService,
    IdempotencyConflictError,
    InactiveSessionError,
    ResultServiceError,
    SessionNotFoundError,
    StorageBusyError,
)
from result_models import StudentResultSubmission, StudentRunStart, clean_result_items, clean_result_steps, isoformat_seconds
from result_uploader import ResultUploader
from runtime_paths import BASE_DIR

def local_timestamp() -> str:
    """Now, in this computer's own time zone, e.g. 2026-10-05T00:12:03+08:00.

    Sentence times used to be written in UTC (ending in Z), 8 hours behind the login time
    shown next to them in Taiwan.
    """
    return datetime.now().astimezone().isoformat(timespec="seconds")


OUT_DIR = BASE_DIR / "out"
OUT_DIR.mkdir(parents=True, exist_ok=True)
TRANSCRIPT_PATH = OUT_DIR / "transcripts.jsonl"
SESSION_AUDIO_DIR = OUT_DIR / "session_audio"
SESSION_AUDIO_DIR.mkdir(parents=True, exist_ok=True)
SESSION_REPORT_DIR = OUT_DIR / "session_reports"
SESSION_REPORT_DIR.mkdir(parents=True, exist_ok=True)
STUDENT_RESULT_DIR = OUT_DIR / "student_results"
student_result_service = ExcelResultService(STUDENT_RESULT_DIR)
result_uploader = ResultUploader(STUDENT_RESULT_DIR)
ENERGY_GATE_RMS = float(os.getenv("ENERGY_GATE_RMS", "0.003"))
ASR_WARMUP_ON_START = os.getenv("ASR_WARMUP_ON_START", "0").strip() in {"1", "true", "True", "yes", "on"}
TTS_RATE = int(os.getenv("TTS_RATE", "185"))
TTS_DEFAULT_VOICE = os.getenv("TTS_DEFAULT_VOICE", "").strip()
TTS_VOICE_BY_SPEAKER = {
    "mother": os.getenv("TTS_VOICE_MOTHER", "").strip(),
    "child": os.getenv("TTS_VOICE_CHILD", "").strip(),
    "nurse": os.getenv("TTS_VOICE_NURSE", "").strip(),
    "narrator": os.getenv("TTS_VOICE_NARRATOR", "").strip(),
    "system": os.getenv("TTS_VOICE_SYSTEM", "").strip(),
}
VOICE_IDLE_KEEPALIVE_SEC = float(os.getenv("VOICE_IDLE_KEEPALIVE_SEC", "3.0"))
VOICE_MAX_UTTERANCE_SEC = float(os.getenv("VOICE_MAX_UTTERANCE_SEC", "20.0"))
VOICE_MIN_AUDIO_MS = float(os.getenv("VOICE_MIN_AUDIO_MS", "200"))
AUDIO_REQUEST_CACHE_SIZE = max(1, int(os.getenv("AUDIO_REQUEST_CACHE_SIZE", "256")))
INITIAL_TENSION = -5.0
DEEPGRAM_REST_URL = "https://api.deepgram.com/v1/listen"
DEEPGRAM_REST_TIMEOUT_SEC = float(os.getenv("DEEPGRAM_REST_TIMEOUT_SEC", "10.0"))
deepgram_api_key = read_api_key("DEEPGRAM_API_KEY", DEEPGRAM_API_KEY_TEMPLATE_VALUE)
deepgram_http_client: Optional[httpx.AsyncClient] = None



def preprocess_audio(mono: np.ndarray) -> np.ndarray:
    """Conservative preprocessing: avoid amplifying silence/noise."""
    if mono is None or len(mono) == 0:
        return mono

    mono = mono.astype(np.float32)

    # remove DC offset
    mono = mono - float(np.mean(mono))

    peak = float(np.max(np.abs(mono))) if len(mono) > 0 else 0.0
    rms = float(np.sqrt(np.mean(np.square(mono)))) if len(mono) > 0 else 0.0

    # Do NOT normalize near-silence/noise; that creates ASR hallucinations.
    if peak < 0.01 or rms < ENERGY_GATE_RMS:
        return mono

    # Normalize only when signal is already strong enough.
    if peak > 0.6:
        mono = mono / peak

    mono = np.clip(mono * 0.95, -1.0, 1.0).astype(np.float32)
    return mono


def compute_rms(x: np.ndarray) -> float:
    if x is None or len(x) == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(x))))


def read_wav_to_mono16k(bytes_data: bytes) -> tuple[np.ndarray, int]:
    """把上傳的 WAV 轉為 mono/16k/float32（-1..1）"""
    return decode_wav_to_mono16k(bytes_data, apply_preprocess=True)


def decode_wav_to_mono16k(bytes_data: bytes, apply_preprocess: bool = True) -> tuple[np.ndarray, int]:
    """把上傳的 WAV 轉為 mono/16k/float32（-1..1）"""
    audio, sr = sf.read(io.BytesIO(bytes_data), dtype="float32", always_2d=True)
    mono = audio.mean(axis=1)
    target_sr = 16000
    if sr != target_sr:
        # 簡單線性重採樣（先用這版就好；日後可換 librosa.resample）
        x_old = np.linspace(0, 1, num=len(mono), endpoint=False, dtype=np.float32)
        new_len = int(len(mono) * (target_sr / sr))
        x_new = np.linspace(0, 1, num=new_len, endpoint=False, dtype=np.float32)
        mono = np.interp(x_new, x_old, mono).astype(np.float32)
        sr = target_sr

    if apply_preprocess:
        mono = preprocess_audio(mono)
    return mono, sr


latest: Dict[str, Any] = {
    "text": "", "emotion": "neutral", "emotion_probs": {},
    "llm": {"intent":"neutral","action_tag":"neutral","sentiment":"neutral","toxicity":0.0,"coercion":0.0,"confidence":0.0,"keywords":[]},
    "semantic_analysis": dict(DEFAULT_SEMANTIC_ANALYSIS),
    "tone_analysis": dict(DEFAULT_TONE_ANALYSIS),
    "tension": INITIAL_TENSION,
    "patienceScore": 100.0,
    "kidEmotionState": "Calm",
    "previousKidEmotionState": "Calm",
    "ts": ""
}

app = FastAPI()
SERVER_HOST = "0.0.0.0"
SERVER_PORT = 8000
discovery_service = DiscoveryService(server_port=SERVER_PORT)


class FusionSession:
    def __init__(self, history_len: int = 3):
        self._prev_tension = INITIAL_TENSION
        self._history = deque(maxlen=history_len)
        self._lock = None

    async def analyze(self, wav: np.ndarray, sr: int) -> Dict[str, Any]:
        loop = asyncio.get_running_loop()
        if self._lock is None:
            self._lock = asyncio.Lock()

        async with self._lock:
            prev = self._prev_tension
            history = list(self._history)
            res, tension = await loop.run_in_executor(None, _run_fusion_pipeline, wav, sr, prev, history)

            text = (res.get("text", "") or "").strip()
            self._prev_tension = tension
            if text:
                self._history.append(text)

        return res

    async def reset(self) -> None:
        if self._lock is None:
            self._lock = asyncio.Lock()
        async with self._lock:
            self._prev_tension = INITIAL_TENSION
            self._history.clear()


class RecordingSession:
    def __init__(self):
        self._lock: Optional[asyncio.Lock] = None
        self._active = False
        self._session_id = ""
        self._path: Optional[Path] = None
        self._writer: Optional[sf.SoundFile] = None
        self._sample_rate = 16000
        self._total_samples = 0

    def _ensure_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def start(self, session_id: str = "") -> Dict[str, Any]:
        lock = self._ensure_lock()
        async with lock:
            if self._writer is not None:
                self._writer.close()

            path = build_session_audio_path(session_id)
            writer = sf.SoundFile(str(path), mode="w", samplerate=self._sample_rate, channels=1, subtype="PCM_16")

            self._active = True
            self._session_id = path.stem
            self._path = path
            self._writer = writer
            self._total_samples = 0
            return self.status()

    async def append(self, mono: np.ndarray, sr: int) -> None:
        if mono is None or len(mono) == 0:
            return

        lock = self._ensure_lock()
        async with lock:
            if not self._active or self._writer is None:
                return

            chunk = mono.astype(np.float32, copy=False)
            if sr != self._sample_rate:
                raise ValueError(f"recording sample rate mismatch: expected {self._sample_rate}, got {sr}")

            self._writer.write(chunk)
            self._writer.flush()
            self._total_samples += int(len(chunk))

    async def stop(self) -> Dict[str, Any]:
        lock = self._ensure_lock()
        async with lock:
            info = self.status()
            if self._writer is not None:
                self._writer.close()
            self._writer = None
            self._active = False
            return info

    def status(self) -> Dict[str, Any]:
        seconds = self._total_samples / float(self._sample_rate) if self._sample_rate > 0 else 0.0
        return {
            "active": self._active,
            "session_id": self._session_id,
            "path": str(self._path) if self._path else "",
            "sample_rate": self._sample_rate,
            "samples": self._total_samples,
            "seconds": round(seconds, 3),
        }


def _run_fusion_pipeline(
    wav: np.ndarray,
    sr: int,
    prev_tension: float,
    history: List[str],
) -> Tuple[Dict[str, Any], float]:
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        sf.write(tmp.name, wav, sr)
        tmp_path = tmp.name
    try:
        res, tension = fuse_once(tmp_path, prev_tension, history)
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
    return res, tension


def _run_text_pipeline(
    input_text: str,
    prev_tension: float,
    history: List[str],
    context: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], float]:
    raw_text = (input_text or "").strip()
    text = sanitize_transcript(raw_text)

    if text:
        llm, llm_window_text = analyze_semantics(text, history, context=context)
        iscore = semantic_tension_score(llm.get("intent", ""), llm.get("coercion", 0.0))
    else:
        llm_window_text = ""
        llm = dict(DEFAULT_SEMANTIC_ANALYSIS)
        iscore = 0.0

    tension = prev_tension if not text else update_tension(
        prev_tension,
        llm.get("intent", ""),
        iscore,
        llm.get("confidence", 0.0),
        0.0,
    )

    kid_emotion_state = tension_to_kid_emotion_state(tension)
    result = {
        "raw_text": raw_text,
        "text": text,
        "semantic_analysis": llm,
        "tone_analysis": dict(DEFAULT_TONE_ANALYSIS),
        "emotion": kid_emotion_state,
        "kidEmotionState": kid_emotion_state,
        "emotion_probs": {},
        "asr": {"asr_confidence": 1.0 if text else 0.0, "language": "zh", "segment_count": 1 if text else 0, "rms": None},
        "llm": llm,
        "llm_window_text": llm_window_text,
        "tension": tension,
        "patienceScore": tension_to_patience_score(tension),
    }
    return result, tension


def _tension_to_stage(tension: float) -> int:
    value = clamp(float(tension or 0.0), -5.0, 5.0)
    if value >= 2.0:
        return 2
    if value >= -0.5:
        return 1
    if value <= -3.0:
        return -1
    return 0


def _build_unity_emotion_payload(
    fusion_res: Dict[str, Any],
    result_type: str = "emotion_result",
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    tension = fusion_res.get("tension", 0.0)
    payload = {
        "type": result_type,
        "source": fusion_res.get("source", "student_speech"),
        "utteranceId": fusion_res.get("utteranceId", ""),
        "scenarioStepId": fusion_res.get("scenarioStepId", ""),
        "scenarioStepIndex": fusion_res.get("scenarioStepIndex", -1),
        "text": fusion_res.get("text", ""),
        "raw_text": fusion_res.get("raw_text", ""),
        "emotion": fusion_res.get("emotion", "neutral"),
        "kidEmotionState": fusion_res.get("kidEmotionState", fusion_res.get("emotion", "neutral")),
        "emotionState": fusion_res.get("kidEmotionState", fusion_res.get("emotion", "neutral")),
        "previousKidEmotionState": fusion_res.get("previousKidEmotionState", ""),
        "tension": tension,
        "patienceScore": fusion_res.get("patienceScore", tension_to_patience_score(tension)),
        "stage": fusion_res.get("stage", _tension_to_stage(tension)),
        "llm": fusion_res.get("llm", fusion_res.get("semantic_analysis", {})),
        "semantic_analysis": fusion_res.get("semantic_analysis", {}),
        "tone_analysis": fusion_res.get("tone_analysis", {}),
        "asr": fusion_res.get("asr", {}),
        "ts": fusion_res.get("ts", ""),
    }
    if extra:
        payload.update(extra)
    return payload


async def analyze_transcript_for_unity(
    transcript: str,
    asr_meta: Optional[Dict[str, Any]] = None,
    unity_meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    loop = asyncio.get_running_loop()
    if fusion_session._lock is None:
        fusion_session._lock = asyncio.Lock()

    async with fusion_session._lock:
        prev = fusion_session._prev_tension
        previous_kid_emotion_state = tension_to_kid_emotion_state(prev)
        history = list(fusion_session._history)
        fusion_res, tension = await loop.run_in_executor(
            None,
            _run_text_pipeline,
            transcript,
            prev,
            history,
            {"current_step_id": unity_meta.get("scenarioStepId", "")} if unity_meta else None,
        )
        fusion_session._prev_tension = tension

        text = (fusion_res.get("text", "") or "").strip()
        if text:
            fusion_session._history.append(text)

    fusion_res = dict(fusion_res)
    fusion_res["ts"] = local_timestamp()
    fusion_res["source"] = "student_speech"
    fusion_res["previousKidEmotionState"] = previous_kid_emotion_state
    fusion_res["stage"] = _tension_to_stage(fusion_res.get("tension", 0.0))
    if unity_meta:
        for key in ("utteranceId", "scenarioStepId", "scenarioStepIndex", "studentRunId"):
            if key in unity_meta:
                fusion_res[key] = unity_meta[key]
    if asr_meta:
        fusion_res["asr"] = {**fusion_res.get("asr", {}), **asr_meta}

    latest.update(fusion_res)
    if (fusion_res.get("text", "") or fusion_res.get("raw_text", "")):
        append_transcript_entry(fusion_res)

    return _build_unity_emotion_payload(fusion_res)


fusion_session = FusionSession()
recording_session = RecordingSession()
audio_result_cache: "OrderedDict[Tuple[str, str], Dict[str, Any]]" = OrderedDict()
audio_request_lock: Optional[asyncio.Lock] = None
active_student_run_id = ""
student_run_contexts: Dict[str, Dict[str, str]] = {}


def get_audio_request_lock() -> asyncio.Lock:
    global audio_request_lock
    if audio_request_lock is None:
        audio_request_lock = asyncio.Lock()
    return audio_request_lock


def cache_audio_result(key: Tuple[str, str], result: Dict[str, Any]) -> None:
    audio_result_cache[key] = dict(result)
    audio_result_cache.move_to_end(key)
    while len(audio_result_cache) > AUDIO_REQUEST_CACHE_SIZE:
        audio_result_cache.popitem(last=False)


def reset_transcripts_file() -> None:
    """Reset transcript log on each server startup for easier debugging."""
    try:
        with open(TRANSCRIPT_PATH, "w", encoding="utf-8") as fp:
            fp.write("")
        print(f"[transcripts] reset: {TRANSCRIPT_PATH}")
    except OSError as e:
        print(f"[transcripts] reset failed: {e}")


def append_transcript_entry(data: Dict[str, Any]) -> None:
    entry = {
        "ts": data.get("ts") or local_timestamp(),
        "text": data.get("text", ""),
        "raw_text": data.get("raw_text", ""),
        "emotion": data.get("emotion", ""),
        "tone_available": data.get("tone_analysis", {}).get("available", False),
        "tone_confidence": data.get("tone_analysis", {}).get("confidence", 0.0),
        "tone_score": data.get("tone_analysis", {}).get("tone_score", 0.0),
        "tension": data.get("tension", 0.0),
        "intent": data.get("semantic_analysis", data.get("llm", {})).get("intent"),
        "sentiment": data.get("semantic_analysis", data.get("llm", {})).get("sentiment"),
        "toxicity": data.get("semantic_analysis", data.get("llm", {})).get("toxicity"),
        "coercion": data.get("semantic_analysis", data.get("llm", {})).get("coercion"),
        "llm_window_text": data.get("llm_window_text", ""),
        "asr_confidence": data.get("asr", {}).get("asr_confidence"),
        "asr_language": data.get("asr", {}).get("language"),
        "asr_segments": data.get("asr", {}).get("segment_count"),
        "asr_rms": data.get("asr", {}).get("rms"),
        "requestId": data.get("utteranceId", ""),
        "scenarioStepId": data.get("scenarioStepId", ""),
        "studentRunId": data.get("studentRunId", ""),
    }
    try:
        with open(TRANSCRIPT_PATH, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError as e:
        print(f"[fusion] failed to append transcript: {e}")



def append_current_student_transcript(data: Dict[str, Any]) -> None:
    student_run_id = str(data.get("studentRunId") or "").strip()
    context = student_run_contexts.get(student_run_id)
    text = str(data.get("text") or "").strip()
    if not context or not text:
        return
    semantic = data.get("semantic_analysis") or data.get("llm") or {}
    try:
        student_result_service.append_student_transcript(
            context["sessionId"],
            student_run_id,
            context["studentId"],
            str(data.get("ts") or local_timestamp()),
            str(data.get("scenarioStepId") or ""),
            str(data.get("utteranceId") or ""),
            text,
            {
                "intent": semantic.get("intent"),
                "toxicity": semantic.get("toxicity"),
                "coercion": semantic.get("coercion"),
                "tension": data.get("tension"),
                "kidEmotionState": data.get("kidEmotionState"),
                "previousKidEmotionState": data.get("previousKidEmotionState"),
            },
        )
    except ResultServiceError as error:
        # Emotion was already calculated; do not turn a transcript I/O problem into
        # an /audio retry that could apply the same utterance twice.
        print(f"[student_results] failed to append student transcript: {error}")


def reset_latest_emotion_state() -> None:
    latest.clear()
    latest.update({
        "text": "",
        "emotion": "neutral",
        "emotion_probs": {},
        "llm": {
            "intent": "neutral",
            "action_tag": "neutral",
            "sentiment": "neutral",
            "toxicity": 0.0,
            "coercion": 0.0,
            "confidence": 0.0,
            "keywords": [],
        },
        "semantic_analysis": dict(DEFAULT_SEMANTIC_ANALYSIS),
        "tone_analysis": dict(DEFAULT_TONE_ANALYSIS),
        "tension": INITIAL_TENSION,
        "patienceScore": 100.0,
        "kidEmotionState": "Calm",
        "previousKidEmotionState": "Calm",
        "ts": "",
    })


def result_service_error_response(error: Exception) -> JSONResponse:
    if isinstance(error, SessionNotFoundError):
        status_code = 404
    elif isinstance(error, (InactiveSessionError, IdempotencyConflictError)):
        status_code = 409
    elif isinstance(error, StorageBusyError):
        status_code = 503
    else:
        status_code = 500
    return JSONResponse(status_code=status_code, content={"ok": False, "error": str(error)})


@app.post("/api/sessions", status_code=201)
async def create_experiment_session():
    try:
        session = await asyncio.to_thread(student_result_service.create_session)
        print(f"[student_results] session created -> {session['sessionId']}")
        return {
            "ok": True,
            "sessionId": session["sessionId"],
            "createdAt": session["createdAt"],
        }
    except ResultServiceError as error:
        return result_service_error_response(error)


@app.get("/api/uploads/status")
async def get_upload_status():
    return await asyncio.to_thread(result_uploader.status)


@app.get("/api/sessions/current")
async def get_current_experiment_session():
    try:
        session = await asyncio.to_thread(student_result_service.get_current_session)
        if session is None:
            return JSONResponse(
                status_code=404,
                content={"ok": False, "error": "no active session"},
            )
        return {
            "ok": True,
            "sessionId": session["sessionId"],
            "createdAt": session["createdAt"],
        }
    except ResultServiceError as error:
        return result_service_error_response(error)


@app.post("/api/student-runs/start")
async def start_student_run(payload: StudentRunStart):
    global active_student_run_id
    try:
        await asyncio.to_thread(student_result_service.ensure_active_session, payload.sessionId)
        result_id = str(payload.resultId)
        await asyncio.to_thread(
            student_result_service.prepare_student_transcript,
            payload.sessionId,
            result_id,
            payload.studentId,
        )
        async with get_audio_request_lock():
            if active_student_run_id != result_id:
                await fusion_session.reset()
                reset_latest_emotion_state()
                audio_result_cache.clear()
                student_run_contexts.clear()
                active_student_run_id = result_id
            student_run_contexts[result_id] = {
                "sessionId": payload.sessionId,
                "studentId": payload.studentId,
                "loginTime": isoformat_seconds(payload.loginTime),
            }
        return {
            "ok": True,
            "sessionId": payload.sessionId,
            "resultId": result_id,
            "studentId": payload.studentId,
            "loginTime": isoformat_seconds(payload.loginTime),
        }
    except ResultServiceError as error:
        return result_service_error_response(error)


@app.put("/api/sessions/{session_id}/results/{result_id}")
async def submit_student_result(
    session_id: str,
    result_id: UUID,
    payload: StudentResultSubmission,
):
    try:
        result = await asyncio.to_thread(
            student_result_service.append_result,
            session_id,
            str(result_id),
            payload.studentId,
            isoformat_seconds(payload.loginTime),
            payload.correctCount,
            payload.toneScore,
            payload.questionScore,
            clean_result_items(payload.items) or None,
            clean_result_steps(payload.steps) or None,
            on_json_saved=result_uploader.enqueue_file,
        )
        print(
            "[student_results] "
            f"session={session_id} result={result_id} duplicate={result['duplicate']} "
            f"student={payload.studentId} received: correctCount={payload.correctCount} "
            f"toneScore={payload.toneScore} questionScore={payload.questionScore} "
            f"-> question={result['questionScore']} total={result['totalScore']}"
        )
        return result
    except ResultServiceError as error:
        return result_service_error_response(error)


def build_session_audio_path(session_id: str) -> Path:
    raw = (session_id or "").strip() or time.strftime("session_%Y%m%d_%H%M%S", time.localtime())
    safe = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in raw)
    safe = safe[:80] or time.strftime("session_%Y%m%d_%H%M%S", time.localtime())
    return SESSION_AUDIO_DIR / f"{safe}.wav"


def build_session_report_path(session_id: str) -> Path:
    raw = (session_id or "").strip() or time.strftime("report_%Y%m%d_%H%M%S", time.localtime())
    safe = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in raw)
    safe = safe[:80] or time.strftime("report_%Y%m%d_%H%M%S", time.localtime())
    return SESSION_REPORT_DIR / f"{safe}.json"


def build_public_url(request: Request, route_path: str) -> str:
    return str(request.base_url).rstrip("/") + route_path


def read_recent_transcripts(limit: int = 100) -> List[Dict[str, Any]]:
    if not TRANSCRIPT_PATH.exists():
        return []
    lines: List[str] = []
    try:
        with open(TRANSCRIPT_PATH, "r", encoding="utf-8") as fp:
            lines = fp.readlines()
    except OSError as e:
        print(f"[fusion] failed to read transcripts: {e}")
        return []

    entries: List[Dict[str, Any]] = []
    for line in lines[-limit:]:
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return entries


def resolve_tts_voice(speaker: str) -> str:
    key = (speaker or "").strip().lower()
    voice = TTS_VOICE_BY_SPEAKER.get(key) or TTS_DEFAULT_VOICE
    return voice.strip()


def synthesize_tts_wav(text: str, speaker: str = "") -> bytes:
    content = (text or "").strip()
    if not content:
        raise ValueError("text is required")

    with tempfile.TemporaryDirectory() as tmpdir:
        if os.name == "nt":
            wav_path = Path(tmpdir) / "tts.wav"
            child_env = os.environ.copy()
            child_env.update(NURSE_TTS_TEXT=content, NURSE_TTS_PATH=str(wav_path),
                             NURSE_TTS_VOICE=resolve_tts_voice(speaker),
                             NURSE_TTS_RATE=str(max(-10, min(10, round((TTS_RATE - 185) / 20)))))
            script = (
                "$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.Speech; "
                "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                "try { if ($env:NURSE_TTS_VOICE) { $s.SelectVoice($env:NURSE_TTS_VOICE) }; "
                "$s.Rate=[int]$env:NURSE_TTS_RATE; "
                "$s.SetOutputToWaveFile($env:NURSE_TTS_PATH); "
                "$s.Speak($env:NURSE_TTS_TEXT) } finally { $s.Dispose() }"
            )
            try:
                subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                               env=child_env, check=True, capture_output=True, timeout=60,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            except (OSError, subprocess.SubprocessError) as error:
                raise RuntimeError("Windows speech synthesis failed; check installed speech voices") from error
            return wav_path.read_bytes()
        aiff_path = Path(tmpdir) / "tts.aiff"
        cmd = ["say", "-r", str(TTS_RATE), "-o", str(aiff_path)]
        voice = resolve_tts_voice(speaker)
        if voice:
            cmd.extend(["-v", voice])
        cmd.append(content)

        try:
            subprocess.run(cmd, check=True, capture_output=True)
        except FileNotFoundError as e:
            raise RuntimeError("system TTS command `say` is not available on this host") from e
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode("utf-8", errors="ignore") if e.stderr else str(e)
            raise RuntimeError(f"TTS synthesis failed: {stderr.strip()}") from e

        audio, sr = sf.read(str(aiff_path), dtype="float32", always_2d=True)
        wav_io = io.BytesIO()
        sf.write(wav_io, audio, sr, format="WAV")
        return wav_io.getvalue()


def get_deepgram_http_client() -> httpx.AsyncClient:
    """Return one pooled client for all complete-utterance REST requests."""
    global deepgram_http_client
    if deepgram_http_client is None or deepgram_http_client.is_closed:
        deepgram_http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(DEEPGRAM_REST_TIMEOUT_SEC),
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
        )
    return deepgram_http_client


def encode_pcm16_wav(wav: np.ndarray, sample_rate: int) -> bytes:
    output = io.BytesIO()
    sf.write(
        output,
        np.asarray(wav, dtype=np.float32),
        int(sample_rate),
        format="WAV",
        subtype="PCM_16",
    )
    return output.getvalue()


async def transcribe_with_deepgram(wav: np.ndarray, sample_rate: int) -> DeepgramTranscriptResult:
    """Send one complete normalized WAV through Deepgram's pre-recorded REST API."""
    if not deepgram_api_key:
        raise DeepgramStreamingError("DEEPGRAM_API_KEY is missing")

    params: List[Tuple[str, str]] = [
        ("model", os.getenv("DEEPGRAM_MODEL", "nova-3").strip()),
        ("language", os.getenv("DEEPGRAM_LANGUAGE", "zh").strip()),
        ("punctuate", "true"),
        ("smart_format", "false"),
    ]
    params.extend(
        ("keyterm", term.strip())
        for term in os.getenv("DEEPGRAM_KEYTERMS", "").split(",")
        if term.strip()
    )

    try:
        response = await get_deepgram_http_client().post(
            DEEPGRAM_REST_URL,
            params=params,
            headers={
                "Authorization": f"Token {deepgram_api_key}",
                "Content-Type": "audio/wav",
            },
            content=encode_pcm16_wav(wav, sample_rate),
        )
        response.raise_for_status()
        payload = response.json()
        channels = ((payload.get("results") or {}).get("channels") or [])
        alternatives = ((channels[0] or {}).get("alternatives") or []) if channels else []
        best = alternatives[0] if alternatives else {}
        metadata = payload.get("metadata") or {}
        detected_language = best.get("detected_language") or best.get("language") or ""
        if not detected_language:
            detected_language = os.getenv("DEEPGRAM_LANGUAGE", "zh").strip()

        return DeepgramTranscriptResult(
            text=(best.get("transcript") or "").strip(),
            confidence=float(best.get("confidence") or 0.0),
            language=str(detected_language),
            is_final=True,
            speech_final=True,
            raw_messages=[{"metadata": metadata, "channel": channels[0] if channels else {}}],
        )
    except (httpx.HTTPError, ValueError, TypeError, KeyError) as error:
        raise DeepgramStreamingError(f"Deepgram REST request failed: {error}") from error


@app.post("/audio")
async def upload_audio(request: Request):
    """Analyze one complete WAV utterance and return Unity's final result."""
    try:
        started_at = time.perf_counter()
        content_type = (request.headers.get("content-type") or "").lower()
        if not content_type.startswith("audio/wav"):
            raise HTTPException(status_code=415, detail="Content-Type must be audio/wav")

        request_id = (request.headers.get("x-request-id") or "").strip()
        scenario_step_id = (request.headers.get("x-scenario-step-id") or "").strip()
        student_run_id = (request.headers.get("x-student-run-id") or "").strip()
        missing = [
            name for name, value in (
                ("X-Request-Id", request_id),
                ("X-Scenario-Step-Id", scenario_step_id),
                ("X-Student-Run-Id", student_run_id),
            ) if not value
        ]
        if missing:
            raise HTTPException(status_code=400, detail=f"missing required header(s): {', '.join(missing)}")

        body_started = time.perf_counter()
        raw = await request.body()
        body_read_ms = round((time.perf_counter() - body_started) * 1000.0, 1)
        if not raw:
            raise HTTPException(status_code=400, detail="empty request body")

        cache_key = (student_run_id, request_id)
        timings = {
            # Time spent receiving the WAV from the headset (slow Wi-Fi shows up here).
            "bodyReadMs": body_read_ms,
            "queueWaitMs": 0.0,
            "decodeMs": 0.0,
            "recordingWriteMs": 0.0,
            "preprocessMs": 0.0,
            "deepgramMs": 0.0,
            "semanticMs": 0.0,
            "transcriptWriteMs": 0.0,
        }
        lock_wait_started = time.perf_counter()
        async with get_audio_request_lock():
            timings["queueWaitMs"] = round(
                (time.perf_counter() - lock_wait_started) * 1000.0, 1
            )
            cached = audio_result_cache.get(cache_key)
            if cached is not None:
                audio_result_cache.move_to_end(cache_key)
                duplicate = dict(cached)
                duplicate["duplicate"] = True
                return duplicate

            if not active_student_run_id:
                raise HTTPException(status_code=409, detail="student run has not been started")
            if student_run_id != active_student_run_id:
                raise HTTPException(status_code=409, detail="X-Student-Run-Id is not the active student run")

            phase_started = time.perf_counter()
            record_wav, sr = await asyncio.to_thread(decode_wav_to_mono16k, raw, False)
            timings["decodeMs"] = round((time.perf_counter() - phase_started) * 1000.0, 1)

            phase_started = time.perf_counter()
            await recording_session.append(record_wav, sr)
            timings["recordingWriteMs"] = round(
                (time.perf_counter() - phase_started) * 1000.0, 1
            )

            phase_started = time.perf_counter()
            wav = await asyncio.to_thread(preprocess_audio, record_wav.copy())
            timings["preprocessMs"] = round(
                (time.perf_counter() - phase_started) * 1000.0, 1
            )
            rms = compute_rms(wav)
            peak = float(np.max(np.abs(wav))) if len(wav) > 0 else 0.0
            print(
                f"[audio] request={request_id} bytes={len(raw)} samples={len(wav)} "
                f"sr={sr} rms={rms:.6f} peak={peak:.6f} gate={ENERGY_GATE_RMS:.6f}"
            )

            previous_state = tension_to_kid_emotion_state(fusion_session._prev_tension)
            analysis_published = False
            if rms < ENERGY_GATE_RMS:
                tension = fusion_session._prev_tension
                fusion_res = {
                    "text": "",
                    "tension": tension,
                    "patienceScore": tension_to_patience_score(tension),
                    "previousKidEmotionState": previous_state,
                    "kidEmotionState": previous_state,
                    "llm": dict(DEFAULT_SEMANTIC_ANALYSIS),
                    "ignored": True,
                    "reason": "low_energy",
                }
            else:
                try:
                    phase_started = time.perf_counter()
                    deepgram_result = await transcribe_with_deepgram(wav, sr)
                    timings["deepgramMs"] = round(
                        (time.perf_counter() - phase_started) * 1000.0, 1
                    )
                except DeepgramStreamingError as error:
                    raise HTTPException(
                        status_code=503,
                        detail=f"Deepgram transcription unavailable: {error}",
                    ) from error

                transcript = (deepgram_result.text or "").strip()
                if not transcript:
                    tension = fusion_session._prev_tension
                    fusion_res = {
                        "text": "",
                        "tension": tension,
                        "patienceScore": tension_to_patience_score(tension),
                        "previousKidEmotionState": previous_state,
                        "kidEmotionState": previous_state,
                        "llm": dict(DEFAULT_SEMANTIC_ANALYSIS),
                        "ignored": True,
                        "reason": "no_speech",
                    }
                else:
                    phase_started = time.perf_counter()
                    fusion_res = dict(await analyze_transcript_for_unity(
                        transcript,
                        asr_meta={
                            "provider": "deepgram",
                            "model": os.getenv("DEEPGRAM_MODEL", "nova-3"),
                            "language": deepgram_result.language,
                            "asr_confidence": deepgram_result.confidence,
                            "sample_rate": sr,
                            "rms": rms,
                        },
                        unity_meta={
                            "utteranceId": request_id,
                            "scenarioStepId": scenario_step_id,
                            "studentRunId": student_run_id,
                        },
                    ))
                    timings["semanticMs"] = round(
                        (time.perf_counter() - phase_started) * 1000.0, 1
                    )
                    analysis_published = True

            llm = fusion_res.get("llm", fusion_res.get("semantic_analysis", {})) or {}
            tension = float(fusion_res.get("tension", fusion_session._prev_tension))
            kid_state = fusion_res.get("kidEmotionState") or tension_to_kid_emotion_state(tension)
            ignored = bool(fusion_res.get("ignored", False)) or not bool(
                (fusion_res.get("text") or "").strip()
            )
            response = {
                "ok": True,
                "ignored": ignored,
                "duplicate": False,
                "requestId": request_id,
                "utteranceId": request_id,
                "scenarioStepId": scenario_step_id,
                "studentRunId": student_run_id,
                "source": "student_speech",
                "text": fusion_res.get("text", ""),
                "tension": tension,
                "patienceScore": tension_to_patience_score(tension),
                "previousKidEmotionState": fusion_res.get("previousKidEmotionState", previous_state),
                "kidEmotionState": kid_state,
                "emotionState": kid_state,
                "intent": llm.get("intent", "neutral"),
                "actionTag": llm.get("action_tag", "neutral"),
                "confidence": float(llm.get("confidence", 0.0) or 0.0),
                "coercion": float(llm.get("coercion", 0.0) or 0.0),
                "processingMs": round((time.perf_counter() - started_at) * 1000.0, 1),
            }
            if ignored:
                response["reason"] = fusion_res.get("reason", "no_speech")

            fusion_res.update({
                "source": "student_speech",
                "utteranceId": request_id,
                "scenarioStepId": scenario_step_id,
                "studentRunId": student_run_id,
                "ts": local_timestamp(),
                # Kept with each sentence for the feedback report's emotion curve.
                "tension": tension,
                "kidEmotionState": kid_state,
            })
            if not analysis_published:
                latest.update(fusion_res)
                if not ignored:
                    append_transcript_entry(fusion_res)
            if not ignored:
                phase_started = time.perf_counter()
                await asyncio.to_thread(append_current_student_transcript, fusion_res)
                timings["transcriptWriteMs"] = round(
                    (time.perf_counter() - phase_started) * 1000.0, 1
                )

            response["processingMs"] = round(
                (time.perf_counter() - started_at) * 1000.0,
                1,
            )
            cache_audio_result(cache_key, response)
            # Whatever the phases above do not explain (so a slow step can never hide).
            timings["otherMs"] = round(response["processingMs"] - sum(timings.values()), 1)
            print("[fusion]", json.dumps({
                "requestId": request_id,
                "text": response["text"],
                "tension": tension,
                "intent": response["intent"],
                "processingMs": response["processingMs"],
                "timings": timings,
            }, ensure_ascii=False))
            return response
    except HTTPException as error:
        return JSONResponse(status_code=error.status_code, content={"ok": False, "error": str(error.detail)})
    except Exception as error:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(error)})


@app.post("/text")
async def upload_text(request: Request):
    """
    測試模式：直接用打字文字走 fusion，排除收音/ASR 問題。
    body: {"text":"..."}
    """
    try:
        payload = await request.json()
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="invalid json body")

        typed = str(payload.get("text", "")).strip()
        if not typed:
            raise HTTPException(status_code=400, detail="text is required")

        # Reuse session state so /text and /audio share same tension/history behavior.
        if fusion_session._lock is None:
            fusion_session._lock = asyncio.Lock()

        async with fusion_session._lock:
            prev = fusion_session._prev_tension
            history = list(fusion_session._history)
            fusion_res, tension = _run_text_pipeline(typed, prev, history)
            fusion_session._prev_tension = tension
            text = (fusion_res.get("text", "") or "").strip()
            if text:
                fusion_session._history.append(text)

        fusion_res = dict(fusion_res)
        fusion_res["ts"] = local_timestamp()
        latest.update(fusion_res)
        append_transcript_entry(fusion_res)

        return {
            "ok": True,
            "mode": "text",
            "text": fusion_res.get("text", ""),
            "raw_text": fusion_res.get("raw_text", ""),
            "semantic_analysis": fusion_res.get("semantic_analysis", {}),
            "tone_analysis": fusion_res.get("tone_analysis", {}),
            "tension": fusion_res.get("tension", 0.0),
        }
    except HTTPException as e:
        return JSONResponse(status_code=e.status_code, content={"ok": False, "error": str(e.detail)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.get("/tts")
def get_tts(text: str, speaker: str = ""):
    try:
        wav_bytes = synthesize_tts_wav(text, speaker)
        return Response(content=wav_bytes, media_type="audio/wav")
    except ValueError as e:
        return JSONResponse(status_code=400, content={"ok": False, "error": str(e)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.post("/session_audio")
async def upload_session_audio(request: Request, session_id: str = ""):
    try:
        raw = await request.body()
        if not raw:
            raise HTTPException(status_code=400, detail="empty request body")

        out_path = build_session_audio_path(session_id)
        with open(out_path, "wb") as fp:
            fp.write(raw)
        print(f"[session_audio] saved -> {out_path}")
        resolved_session_id = out_path.stem
        public_url = build_public_url(request, f"/session_audio/{resolved_session_id}")
        return {"ok": True, "session_id": resolved_session_id, "path": str(out_path), "url": public_url, "bytes": len(raw)}
    except HTTPException as e:
        return JSONResponse(status_code=e.status_code, content={"ok": False, "error": str(e.detail)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.get("/session_audio/{session_id}")
def get_session_audio(session_id: str):
    path = build_session_audio_path(session_id)
    if not path.exists():
        return JSONResponse(status_code=404, content={"ok": False, "error": "session audio not found"})
    return FileResponse(str(path), media_type="audio/wav", filename=path.name)


@app.post("/recording/start")
async def start_recording(request: Request, session_id: str = ""):
    try:
        info = await recording_session.start(session_id)
        public_url = build_public_url(request, f"/session_audio/{info['session_id']}")
        print(f"[recording] started -> {info['path']}")
        return {"ok": True, **info, "url": public_url}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.post("/recording/stop")
async def stop_recording(request: Request):
    try:
        info = await recording_session.stop()
        if not info.get("session_id"):
            return {"ok": True, **info, "url": ""}
        public_url = build_public_url(request, f"/session_audio/{info['session_id']}")
        print(f"[recording] stopped -> {info['path']} ({info['seconds']}s)")
        return {"ok": True, **info, "url": public_url}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.get("/recording/status")
def get_recording_status(request: Request):
    info = recording_session.status()
    public_url = build_public_url(request, f"/session_audio/{info['session_id']}") if info.get("session_id") else ""
    return {"ok": True, **info, "url": public_url}


@app.post("/session_report")
async def upload_session_report(request: Request, session_id: str = ""):
    try:
        raw = await request.body()
        if not raw:
            raise HTTPException(status_code=400, detail="empty request body")

        out_path = build_session_report_path(session_id)
        with open(out_path, "wb") as fp:
            fp.write(raw)
        resolved_session_id = out_path.stem
        public_url = build_public_url(request, f"/session_report/{resolved_session_id}")
        print(f"[session_report] saved -> {out_path}")
        return {"ok": True, "session_id": resolved_session_id, "path": str(out_path), "url": public_url, "bytes": len(raw)}
    except HTTPException as e:
        return JSONResponse(status_code=e.status_code, content={"ok": False, "error": str(e.detail)})
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.get("/session_report/{session_id}")
def get_session_report(session_id: str):
    path = build_session_report_path(session_id)
    if not path.exists():
        return JSONResponse(status_code=404, content={"ok": False, "error": "session report not found"})
    return FileResponse(str(path), media_type="application/json", filename=path.name)


# Feedback reports (written by ExcelResultService when a result is submitted).
#   /reports                 overview of the most recent day that has results
#   /reports/2026-10-04      overview of that day
#   /reports/2026-10-04/x    one student's report
REPORT_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
REPORT_FILE_RE = re.compile(r"^[A-Za-z0-9_-]{1,100}\.html$")


def _report_file(date_text: str, file_name: str):
    if not REPORT_DATE_RE.fullmatch(date_text) or not REPORT_FILE_RE.fullmatch(file_name):
        return JSONResponse(status_code=404, content={"ok": False, "error": "report not found"})
    path = student_result_service.output_dir / date_text / file_name
    if not path.is_file():
        return JSONResponse(status_code=404, content={"ok": False, "error": "report not found"})
    return FileResponse(str(path), media_type="text/html; charset=utf-8")


@app.get("/reports")
def get_latest_report_overview():
    root = student_result_service.output_dir
    days = sorted(
        folder.name for folder in root.iterdir()
        if folder.is_dir() and REPORT_DATE_RE.fullmatch(folder.name) and (folder / "index.html").is_file()
    ) if root.exists() else []
    if not days:
        return JSONResponse(status_code=404, content={"ok": False, "error": "no reports yet"})
    return RedirectResponse(url=f"/reports/{days[-1]}/index.html")


@app.get("/reports/{date_text}")
def get_report_overview(date_text: str):
    return RedirectResponse(url=f"/reports/{date_text}/index.html")


@app.get("/reports/{date_text}/{file_name}")
def get_report(date_text: str, file_name: str):
    return _report_file(date_text, file_name)


@app.get("/last")
def get_last():
    return JSONResponse(latest)


@app.get("/transcripts")
def get_transcripts(limit: int = 50):
    limit = max(1, min(limit, 500))
    entries = read_recent_transcripts(limit)
    return {"items": entries, "count": len(entries)}


def _voice_error(code: str, message: str) -> Dict[str, Any]:
    return {
        "type": "error",
        "code": code,
        "message": message,
        "ts": local_timestamp(),
    }


def _audio_ms(byte_count: int, sample_rate: int, channels: int = 1) -> float:
    bytes_per_sample = 2
    denom = max(1, sample_rate * channels * bytes_per_sample)
    return (byte_count / denom) * 1000.0


def _parse_voice_control(raw_text: str) -> Dict[str, Any]:
    try:
        payload = json.loads(raw_text or "{}")
    except json.JSONDecodeError:
        return {"type": "invalid_json"}
    if not isinstance(payload, dict):
        return {"type": "invalid_json"}
    return payload


@app.websocket("/voice")
async def voice_ws(ws: WebSocket):
    await ws.accept()

    dg_session: Optional[DeepgramStreamingSession] = None
    sample_rate = int(os.getenv("DEEPGRAM_SAMPLE_RATE", "16000"))
    audio_bytes = 0
    utterance_started_at = 0.0
    request_id = ""
    unity_meta: Dict[str, Any] = {}

    async def close_deepgram_session() -> None:
        nonlocal dg_session
        if dg_session is not None:
            try:
                await dg_session.close()
            except Exception as e:
                print(f"[voice] deepgram close failed: {e}")
            dg_session = None

    try:
        while True:
            try:
                message = await asyncio.wait_for(ws.receive(), timeout=VOICE_IDLE_KEEPALIVE_SEC)
            except asyncio.TimeoutError:
                if dg_session is not None:
                    try:
                        await dg_session.keep_alive()
                    except Exception as e:
                        print(f"[voice] keepalive failed: {e}")
                        await ws.send_json(_voice_error("deepgram_disconnected", "Deepgram stream disconnected"))
                        await close_deepgram_session()
                continue

            if message.get("type") == "websocket.disconnect":
                raise WebSocketDisconnect()

            raw_text = message.get("text")
            audio_chunk = message.get("bytes")

            if raw_text is not None:
                payload = _parse_voice_control(raw_text)
                msg_type = str(payload.get("type", "")).strip().lower()

                if msg_type == "start_utterance":
                    await close_deepgram_session()

                    try:
                        sample_rate = int(payload.get("sampleRate") or payload.get("sample_rate") or sample_rate)
                    except (TypeError, ValueError):
                        sample_rate = 16000

                    audio_bytes = 0
                    utterance_started_at = time.perf_counter()
                    request_id = str(payload.get("requestId") or payload.get("request_id") or "")
                    unity_meta = {
                        "utteranceId": str(payload.get("utteranceId") or payload.get("utterance_id") or request_id),
                    }
                    if payload.get("scenarioStepId") is not None:
                        unity_meta["scenarioStepId"] = str(payload.get("scenarioStepId"))
                    if payload.get("scenarioStepIndex") is not None:
                        try:
                            unity_meta["scenarioStepIndex"] = int(payload.get("scenarioStepIndex"))
                        except (TypeError, ValueError):
                            unity_meta["scenarioStepIndex"] = -1

                    try:
                        dg_session = DeepgramStreamingSession(sample_rate=sample_rate)
                        await dg_session.connect()
                    except DeepgramStreamingError as e:
                        await ws.send_json(_voice_error("deepgram_start_failed", str(e)))
                        await close_deepgram_session()
                        continue
                    except Exception as e:
                        await ws.send_json(_voice_error("deepgram_start_failed", str(e)))
                        await close_deepgram_session()
                        continue

                    await ws.send_json({
                        "type": "voice_ready",
                        "sampleRate": sample_rate,
                        "encoding": "linear16",
                        "requestId": request_id,
                    })
                    continue

                if msg_type == "end_utterance":
                    if dg_session is None:
                        await ws.send_json(_voice_error("not_recording", "No active utterance"))
                        continue

                    end_received_at = time.perf_counter()
                    audio_duration_ms = _audio_ms(audio_bytes, sample_rate)
                    if audio_duration_ms < VOICE_MIN_AUDIO_MS:
                        await close_deepgram_session()
                        await ws.send_json(_voice_error("too_short", "Audio is too short"))
                        continue

                    try:
                        dg_result: DeepgramTranscriptResult = await dg_session.finalize()
                    except Exception as e:
                        await close_deepgram_session()
                        await ws.send_json(_voice_error("deepgram_finalize_failed", str(e)))
                        continue
                    finally:
                        await close_deepgram_session()

                    transcript = (dg_result.text or "").strip()
                    transcript_at = time.perf_counter()
                    if not transcript:
                        await ws.send_json(_voice_error("no_speech", "No speech detected"))
                        continue

                    try:
                        response = await analyze_transcript_for_unity(
                            transcript,
                            asr_meta={
                                "provider": "deepgram",
                                "model": os.getenv("DEEPGRAM_MODEL", "nova-3"),
                                "language": dg_result.language,
                                "asr_confidence": dg_result.confidence,
                                "sample_rate": sample_rate,
                                "audio_ms": round(audio_duration_ms, 1),
                            },
                            unity_meta=unity_meta,
                        )
                    except Exception as e:
                        await ws.send_json(_voice_error("emotion_analysis_failed", str(e)))
                        continue

                    sent_at = time.perf_counter()
                    response["requestId"] = request_id
                    response["latency"] = {
                        "utterance_ms": round((end_received_at - utterance_started_at) * 1000.0, 1),
                        "deepgram_finalize_ms": round((transcript_at - end_received_at) * 1000.0, 1),
                        "emotion_analysis_ms": round((sent_at - transcript_at) * 1000.0, 1),
                        "end_to_result_ms": round((sent_at - end_received_at) * 1000.0, 1),
                    }
                    await ws.send_json(response)
                    print("[voice]", json.dumps({
                        "text": response.get("text", ""),
                        "tension": response.get("tension", 0.0),
                        "intent": response.get("llm", {}).get("intent", ""),
                        "end_to_result_ms": response["latency"]["end_to_result_ms"],
                    }, ensure_ascii=False))
                    continue

                if msg_type in {"cancel_utterance", "cancel"}:
                    await close_deepgram_session()
                    await ws.send_json({"type": "voice_cancelled", "requestId": request_id})
                    continue

                await ws.send_json(_voice_error("unknown_message", f"Unknown control message: {msg_type}"))
                continue

            if audio_chunk is not None:
                if dg_session is None:
                    await ws.send_json(_voice_error("not_recording", "Audio received before start_utterance"))
                    continue

                if time.perf_counter() - utterance_started_at > VOICE_MAX_UTTERANCE_SEC:
                    await close_deepgram_session()
                    await ws.send_json(_voice_error("utterance_timeout", "Utterance exceeded max duration"))
                    continue

                audio_bytes += len(audio_chunk)
                try:
                    await dg_session.send_audio(audio_chunk)
                except Exception as e:
                    await close_deepgram_session()
                    await ws.send_json(_voice_error("deepgram_send_failed", str(e)))
                continue
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[voice] websocket error: {e}")
        try:
            await ws.send_json(_voice_error("server_error", str(e)))
        except Exception:
            pass
    finally:
        await close_deepgram_session()

@app.websocket("/ws")
async def ws_feed(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            await ws.send_text(json.dumps(latest, ensure_ascii=False))
            await asyncio.sleep(0.5)  # 推播頻率，可調
    except Exception:
        pass

@app.on_event("startup")
async def on_start():
    await result_uploader.start()
    await discovery_service.start()
    reset_transcripts_file()

    if not ASR_WARMUP_ON_START:
        print("[warmup] skipped on startup (ASR_WARMUP_ON_START=0)")
        return

    try:
        print("[warmup] loading ASR model... this may take a while on first run")
        warmup_start = time.time()
        warmup_model()
        elapsed = time.time() - warmup_start
        print(f"[warmup] SenseVoice ready in {elapsed:.2f}s")
    except Exception as e:
        print(f"[warmup] SenseVoice warmup failed: {e}")


@app.on_event("shutdown")
async def on_shutdown():
    await result_uploader.stop()
    await discovery_service.stop()
    global deepgram_http_client
    if deepgram_http_client is not None and not deepgram_http_client.is_closed:
        await deepgram_http_client.aclose()
    deepgram_http_client = None

if __name__ == "__main__":
    # 0.0.0.0 讓區網裝置（Quest）可連；port 可自訂
    uvicorn.run(app, host=SERVER_HOST, port=SERVER_PORT)
