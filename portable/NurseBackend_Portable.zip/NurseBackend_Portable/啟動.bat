@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0python\python.exe" (
    echo 找不到 Python，請先完整解壓縮整個資料夾。
    pause
    exit /b 1
)
"%~dp0python\python.exe" -B -u "%~dp0backend\launcher.py" %*
set "BACKEND_EXIT=%ERRORLEVEL%"
echo.
echo 後端已停止，結束代碼：%BACKEND_EXIT%
echo 啟動錯誤請查看 backend\logs\startup-error.log
pause
exit /b %BACKEND_EXIT%
